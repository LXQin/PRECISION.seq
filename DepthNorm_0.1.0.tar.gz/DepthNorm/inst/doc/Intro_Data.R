## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, warning = FALSE, message = FALSE----------------------------------
library(DepthNorm)
library(DESeq)
library(limma)

## ----warning = FALSE, message = FALSE-----------------------------------------
benchmark.log = benchmark.log = log2(benchmark + 1)
boxplot(benchmark.log, 
        col = ifelse(grepl("MXF", colnames(benchmark.log)),
                     rainbow(2)[1], rainbow(2)[2]),
        ylab = "Log2 Count", ylim = c(0, 20),
        xaxt = "n", outline = FALSE)
legend("topright",c("MXF", "PMFH"), bty = "n",
       pch = "x", cex = 1, col = c(rainbow(2)[1], rainbow(2)[2]))

## ----warning=FALSE, message=FALSE---------------------------------------------
emp.group = c(rep(c(rep('MXF',9),rep('PMFH',9)),3))
benchmark.voom = DE.voom(RC = benchmark, groups = emp.group, P = 0.01)
DE.bench = benchmark.voom$id.list
benchmark.voom.dat = data.frame(dm = benchmark.voom$p.val[,2],
                            p.value = benchmark.voom$p.val[,1])
mask <- with(benchmark.voom.dat, p.value < .01)
cols <- ifelse(mask,"red", "black")
with(benchmark.voom.dat, plot(dm, -log10(p.value), cex = .5, pch = 16,
                          col = cols, xlim = c(-3.6, 3.6),
                          ylim = c(0, 6),
                          xlab = "Mean Difference: PMFH - MXF"))
abline(h = 2, lty = 2)

## ----warning=FALSE, message=FALSE---------------------------------------------
cols = ifelse(rownames(benchmark.log) %in% DE.bench, "red", "black")
plot(rowMeans(benchmark.log),
     apply(benchmark.log[,grepl("MXF", colnames(benchmark.log))], 1, mean) - 
       apply(benchmark.log[,grepl("PMFH", colnames(benchmark.log))], 1, mean),
     pch = 16, cex = 0.5, col = cols,
     xlab = "Group Mean Average of Log2 Count", 
     ylab = "Group Mean Difference of Log2 Count",
     main = "")

## ----warning = FALSE, message = FALSE-----------------------------------------
test.log = log2(test + 1)
boxplot(test.log, 
        col = ifelse(grepl("MXF", colnames(benchmark.log)),
                     rainbow(2)[1], rainbow(2)[2]),
        xaxt = "n", outline = FALSE, ylim = c(0, 20))
legend("topleft",c("MXF", "PMFH"), bty = "n",
       pch = "x", cex = 1, col = c(rainbow(2)[1], rainbow(2)[2]))

## ----warning=FALSE, message=FALSE---------------------------------------------
test.voom = DE.voom(RC = test, groups = emp.group, P = 0.01)
test.voom.dat = data.frame(dm = test.voom$p.val[,2],
                            p.value = test.voom$p.val[,1])
mask = with(test.voom.dat, p.value < .01)
cols = ifelse(mask,"red", "black")
with(test.voom.dat, plot(dm, -log10(p.value), cex = .5, pch = 16,
                         ylim = c(0, 6), xlim = c(-3.6, 3.6),
                         col = cols, xlab = "Mean Difference: PMFH - MXF"))
abline(h = 2, lty = 2)

## ----warning=FALSE, message=FALSE---------------------------------------------
pval.bench.test = data.frame(cbind(bench.pval = benchmark.voom$p.val[,1], 
                        test.pval = test.voom$p.val[rownames(benchmark.voom$p.val),1]))
attach(pval.bench.test)
bench.sig <- (bench.pval < 0.01)
test.sig <- (test.pval < 0.01)
venn2 <- cbind(bench.sig, test.sig)
vennDiagram(vennCounts(venn2), 
            names = c("Benchmark", "Test"), 
            cex = 1.5, counts.col = rainbow(1))

## ----warning=FALSE, message=FALSE---------------------------------------------
benchmark.log.MXF.mean = rowMeans(benchmark.log[, grepl("MXF", colnames(benchmark.log))])
plot(benchmark.log.MXF.mean,
     rowMeans(test.log[,grepl("MXF", colnames(test.log))]), pch = 16, cex = 0.5,
     xlab = "Group Mean Average of Log2 Count in Benchmark", 
     ylab = "Group Mean Average of Log2 Count in Test",
     main = "MXF", xlim = c(0, 20), ylim = c(0, 20))
abline(0,1)

## ----warning=FALSE, message=FALSE---------------------------------------------
benchmark.log.PMFH.mean = rowMeans(benchmark.log[, grepl("PMFH", colnames(benchmark.log))])
plot(benchmark.log.PMFH.mean,
     rowMeans(test.log[,grepl("PMFH", colnames(test.log))]), pch = 16, cex = 0.5,
     xlab = "Group Mean Average of Log2 Count in Benchmark", 
     ylab = "Group Mean AVerage of Log2 Count in Test",
     main = "PMFH", xlim = c(0, 20), ylim = c(0, 20))
abline(0,1)

## ----warning=FALSE, message=FALSE---------------------------------------------
simulated = simu(proportion_L = 0.0175, proportion_R = 0.0225, median_L = -0.5, median_R = 0.5, numsets = 100)

head(simulated$simulated_benchmark[[1]])[,1:5]
head(simulated$simulated_test[[1]])[,1:5]

