## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, warning = FALSE, message = FALSE----------------------------------
library(DepthNorm)
library(DESeq)

## ----warning = FALSE, message = FALSE-----------------------------------------
emp.group = c(rep(c(rep('MXF',9),rep('PMFH',9)),3))
test.TC = norm.TC(test, emp.group)
test.UQ = norm.UQ(test, emp.group)
test.med = norm.med(test, emp.group)
test.TMM = norm.TMM(test, emp.group)
test.DESeq = norm.DESeq(test, emp.group)
test.PoissonSeq = norm.PoissonSeq(test)
test.QN = norm.QN(test)
test.SVA = norm.SVA(test, emp.group)
test.RUVg =  norm.RUV(test, emp.group, method = "RUVg")
test.RUVs =  norm.RUV(test, emp.group, method = "RUVs")
test.RUVr =  norm.RUV(test, emp.group, method = "RUVr")

head(test.TMM$scaling.factor)
head(test.TMM$dat.normed[,1:5])

head(test.SVA$adjust.factor)
head(test.SVA$dat.normed[,1:5])

## -----------------------------------------------------------------------------
edgeR.benchmark = DE.edgeR(benchmark, emp.group)
voom.benchmark = DE.voom(benchmark, emp.group)

edgeR.test.TMM = DE.edgeR(test.TMM$dat.normed, emp.group)
voom.test.TMM = DE.voom(test.TMM$dat.normed, emp.group)

edgeR.test.RUVr = DE.edgeR(test, emp.group, 
                           normalized = FALSE,
                           adjust = test.RUVr$adjust.factor)
voom.test.RUVr = DE.voom(test, emp.group, 
                         normalized = FALSE,
                         adjust = test.RUVr$adjust.factor)

head(voom.benchmark$id.list)
head(voom.benchmark$p.val)

head(voom.test.RUVr$id.list)
head(voom.test.RUVr$p.val)

